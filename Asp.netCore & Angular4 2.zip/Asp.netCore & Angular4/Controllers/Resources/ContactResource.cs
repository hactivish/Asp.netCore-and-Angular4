using System.ComponentModel.DataAnnotations;

namespace vega.Controllers.Resources
{
    //Api Resource
    public class ContactResource
    {
        [Required]//data annotation for validation
        [StringLength(255)] //data annotation for validation
        public string Name { get; set; }
        
        [StringLength(255)]
        public string Email { get; set; }
   
        [Required]
        [StringLength(255)]
        public string Phone { get; set; }
   
    }
}

// namespace vega.Controllers.Resources
// {
//     public class ContactResource
//     {
//         [Required]
//         [StringLength(255)]
//         public string Name { get; set; }
        
//         [StringLength(255)]
//         public string Email { get; set; }
   
//         [Required]
//         [StringLength(255)]
//         public string Phone { get; set; }
   
//     }
// }