using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace vega.Controllers.Resources
{
    public class MakeResource
    {
        public int Id{get;set;}
        // [Required] //setting name colum as required
        // [StringLength(255)]//setting to 255 lenght

        public string Name{get;set;}

        public ICollection<ModelResource> Models{get;set;} //cmmand + . and select the namespace ="using System.Collections.Generic;"

        public MakeResource()
        {
            Models =new Collection<ModelResource>();
        } 
    }
}