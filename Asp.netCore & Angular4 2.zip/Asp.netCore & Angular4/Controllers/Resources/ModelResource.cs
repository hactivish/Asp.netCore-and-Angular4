namespace vega.Controllers.Resources
{
    public class ModelResource
    {
        //  [Required]
        //  [StringLength(255)]

        public int Id{get;set;}
        public string Name{get;set;}

    }
}