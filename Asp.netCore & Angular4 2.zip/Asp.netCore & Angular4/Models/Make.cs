using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace vega.Models
{

    //Makes is a static domain model since a MAKE(i.e compnay maker had only static name)
    public class Make
    {
        public int Id{get;set;}
        [Required] //setting name colum as required
        [StringLength(255)]//setting to 255 lenght

        public string Name{get;set;}

        //Collection model here because a MAKE9 (i.e BMW have many model)
        public ICollection<Model> Models{get;set;} //cmmand + . and select the namespace ="using System.Collections.Generic;"

        //Initialize MAKE for new instance  to prevent NULL reference
        public Make()
        {
           //you can also use LIST/Ilist intead of collection
            Models =new Collection<Model>();
        }
    }
}